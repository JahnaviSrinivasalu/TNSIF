package com.example.student;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
import org.springframework.beans.factory.annotation.Autowired;

@Component
public class EndpointLogger implements CommandLineRunner {

    @Autowired
    private RequestMappingHandlerMapping requestMappingHandlerMapping;

    @Override
    public void run(String... args) {
        System.out.println("Listing all endpoints with full URLs:");

        String baseUrl = "http://localhost:8080";

        requestMappingHandlerMapping.getHandlerMethods().forEach((info, method) -> {
            if (info.getPatternsCondition() != null && info.getMethodsCondition() != null) {
                for (String pattern : info.getPatternsCondition().getPatterns()) {
                    String methods = info.getMethodsCondition().getMethods().toString();
                    methods = methods.replace("[", "").replace("]", "");
                    String fullUrl = baseUrl + pattern;
                    System.out.println(methods + " " + fullUrl);
                }
            }
        });
    }
}
