import { Products } from "./products";
import "./App.css";

function App() {
  return (
    <div className="App">
      <Products />
    </div>
  );
}

export default App;
